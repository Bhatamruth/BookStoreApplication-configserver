package com.amruth.shoppingcart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amruth.shoppingcart.model.ShoppingCartRequest;
import com.amruth.shoppingcart.model.ShoppingcartResponse;
import com.amruth.shoppingcart.service.ShoppingCartService;

@RestController
@RequestMapping("/shoppingcart")
public class ShoppingCartController {

	@Autowired
	private ShoppingCartService shoppingCartService;
	
	@PostMapping("/{userId}/products")
	public ResponseEntity  addProductsToCart(
			@PathVariable Long userId,
			@RequestBody List<ShoppingCartRequest> reqProductList
			) {
		ShoppingcartResponse response =  shoppingCartService.processAddRequest(userId,reqProductList);
		
		return new ResponseEntity(response,HttpStatus.CREATED);
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity getShoppingCart(@PathVariable Long userId)
	{
		return ResponseEntity.ok(shoppingCartService.getShoppingCart(userId));
	}
}
